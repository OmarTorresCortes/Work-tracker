package com.example.worktracker.ui.theme

import androidx.compose.ui.graphics.Color

val grey2 = Color(0xFF353535)
val grey3 = Color(0xFF242424)

val blue1 = Color(0xFF2F5D7E)
val blue2 = Color(0xffB8DBF1)
val blue3 = Color(0xffF2F6FD)
val blue4 = Color(0xFFDEE3EB)
val blue5 = Color(0xFFCACFD8)
